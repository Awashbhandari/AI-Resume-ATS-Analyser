package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Scores experience by:
 * 1. Extracting date ranges from resume text
 * 2. Calculating total years of experience
 * 3. If JD experience requirement given — comparing against it
 *    If not given — using default scale
 */
@Service
public class ExperienceScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ExperienceScoringService.class);

    // Matches patterns like: Jan 2021 – Dec 2023, 2019 - 2022, 2020 - Present
    private static final Pattern DATE_RANGE_PATTERN = Pattern.compile(
            "(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)?[\\s.]*(\\d{4})" +
                    "\\s*[-–—\\u2014\\u2013to]+\\s*" +
            "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)?[\\s.]*(\\d{4}|present|current|now|till date)",
            Pattern.CASE_INSENSITIVE
    );

    // Matches "X years" or "X+ years"
    private static final Pattern YEARS_PATTERN = Pattern.compile(
            "(\\d+)\\+?\\s*years?\\s*(of)?\\s*(experience|exp)?",
            Pattern.CASE_INSENSITIVE
    );

    public static class ExperienceResult {
        public double score;
        public int yearsExperience;
        public List<String> dateRanges = new ArrayList<>();
        public boolean hasCurrentRole;
        public int jobCount;
    }

    public ExperienceResult score(String resumeText, String experienceRequired) {
        ExperienceResult result = new ExperienceResult();

        // ── Extract date ranges ──
        Matcher matcher = DATE_RANGE_PATTERN.matcher(resumeText);
        int maxYear = 0, minYear = 9999;
        boolean hasPresent = false;

        while (matcher.find()) {
            result.dateRanges.add(matcher.group().trim());
            result.jobCount++;

            try {
                int startYear = Integer.parseInt(matcher.group(2));
                minYear = Math.min(minYear, startYear);

                String endStr = matcher.group(4).toLowerCase();
                if (endStr.matches("present|current|now|till date")) {
                    hasPresent = true;
                    maxYear = LocalDate.now().getYear();
                } else {
                    int endYear = Integer.parseInt(endStr);
                    maxYear = Math.max(maxYear, endYear);
                }
            } catch (Exception ignored) {}
        }

        result.hasCurrentRole = hasPresent;

        // Calculate years from date ranges
        if (minYear != 9999 && maxYear != 0) {
            result.yearsExperience = maxYear - minYear;
        }

        // Also check for explicit "X years" mentions
        Matcher yearsMatcher = YEARS_PATTERN.matcher(resumeText);
        if (yearsMatcher.find()) {
            int explicitYears = Integer.parseInt(yearsMatcher.group(1));
            result.yearsExperience = Math.max(result.yearsExperience, explicitYears);
        }

        result.yearsExperience = Math.max(0, result.yearsExperience);

        // ── Score based on JD requirement or default scale ──
        if (experienceRequired != null && !experienceRequired.isBlank()) {
            result.score = scoreAgainstJD(result.yearsExperience, experienceRequired);
        } else {
            result.score = defaultScale(result.yearsExperience);
        }

        log.info("ExperienceScore: {}/100 — years:{} jobs:{} currentRole:{}",
                result.score, result.yearsExperience, result.jobCount, result.hasCurrentRole);

        return result;
    }

    /**
     * Score experience against JD requirement.
     * "2+ years", "minimum 3 years", "fresher", "5 years"
     */
    private double scoreAgainstJD(int resumeYears, String requirement) {
        String lower = requirement.toLowerCase();

        // Fresher / entry level — any experience is fine
        if (lower.contains("fresher") || lower.contains("entry") ||
            lower.contains("no experience") || lower.contains("0 year")) {
            return resumeYears >= 0 ? 100 : 60;
        }

        // Extract required years from JD
        Matcher m = Pattern.compile("(\\d+)").matcher(requirement);
        if (!m.find()) return defaultScale(resumeYears);

        int requiredYears = Integer.parseInt(m.group(1));

        if (resumeYears >= requiredYears) {
            return 100; // Meets or exceeds
        }

        int gap = requiredYears - resumeYears;
        if (gap <= 1) return 70;  // Slightly below — within 1 year
        if (gap <= 2) return 45;  // Moderately below
        if (gap <= 3) return 20;  // Significantly below
        return 10;                // Very far below
    }

    /**
     * Default scoring scale when no JD experience requirement given.
     */
    private double defaultScale(int years) {
        if (years >= 9) return 100;
        if (years >= 7) return 88;
        if (years >= 5) return 78;
        if (years >= 3) return 65;
        if (years >= 2) return 40;
        if (years >= 1) return 20;
        return 10;
    }
}
