package com.example.jobsathi.service.scoring;

import com.example.jobsathi.dto.GrammarIssue;
import lombok.extern.slf4j.Slf4j;
import org.languagetool.JLanguageTool;
import org.languagetool.language.AmericanEnglish;
import org.languagetool.rules.RuleMatch;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Scores grammar using LanguageTool library.
 * Already in pom.xml — no AI needed.
 *
 * Scoring:
 *   Start at 100
 *   Minus 10 per significant grammar/spelling error
 *   Minimum score = 10
 */
@Service
public class GrammarScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(GrammarScoringService.class);

    private JLanguageTool languageTool;

    public GrammarScoringService() {
        try {
            this.languageTool = new JLanguageTool(new AmericanEnglish());
        } catch (Exception e) {
            log.warn("LanguageTool initialization failed: {}", e.getMessage());
        }
    }

    public static class GrammarResult {
        public double score;
        public int issueCount;
        public List<GrammarIssue> issues = new ArrayList<>();
    }

    public GrammarResult score(String resumeText) {
        GrammarResult result = new GrammarResult();

        if (languageTool == null) {
            log.warn("LanguageTool not available — returning default grammar score");
            result.score = 70;
            return result;
        }

        try {
            // Limit text to avoid performance issues
            String textToCheck = resumeText.length() > 3000
                    ? resumeText.substring(0, 3000)
                    : resumeText;

            List<RuleMatch> matches = languageTool.check(textToCheck);

            for (RuleMatch match : matches) {
                // Skip style suggestions — only count real errors
                String category = match.getRule().getCategory().getId().toString();
                if (category.contains("STYLE") ||
                        category.contains("TYPOGRAPHY") ||
                        category.contains("SPELLING") ||
                        category.contains("MORFOLOGIK") ||
                        category.contains("CASING") ||
                        category.contains("CAPITALIZATION") ||
                        match.getRule().getId().contains("MORFOLOGIK") ||
                        match.getMessage().toLowerCase().contains("spelling"))
                    continue;

                GrammarIssue issue = GrammarIssue.builder()
                        .errorText(textToCheck.substring(
                                Math.max(0, match.getFromPos()),
                                Math.min(textToCheck.length(), match.getToPos())))
                        .message(match.getMessage())
                        .suggestion(match.getSuggestedReplacements().isEmpty()
                                ? "" : match.getSuggestedReplacements().get(0))
                        .category(category)
                        .ruleId(match.getRule().getId())
                        .fromPos(match.getFromPos())
                        .toPos(match.getToPos())
                        .build();
                result.issues.add(issue);
            }

            result.issueCount = result.issues.size();

            // Score: start 100, minus 10 per error, min 10
            double penalty = result.issueCount * 10.0;
            result.score   = Math.max(10, 100 - penalty);

        } catch (Exception e) {
            log.error("Grammar check failed: {}", e.getMessage());
            result.score = 70; // default if check fails
        }

        log.info("GrammarScore: {}/100 — issues:{}", result.score, result.issueCount);
        return result;
    }
}
