package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Scores keyword density using Term Frequency (TF) analysis.
 * If JD given — computes overlap between resume and JD keywords.
 * If no JD — counts important tech/professional keywords in resume.
 */
@Service
public class KeywordScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(KeywordScoringService.class);

    // Common stop words to ignore
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "the","and","for","are","was","were","with","have","has","had","been","will",
            "would","could","should","may","might","shall","can","this","that","these",
            "those","they","them","their","our","your","his","her","its","we","you","he",
            "she","it","a","an","of","in","to","is","as","at","by","or","on","not","but",
            "from","more","also","than","about","into","over","after","under","during",
            "through","between","among","within","without","including","using","used",
            "able","each","both","all","any","few","most","other","some","such",
            "while","when","where","how","what","which","who","why","then","than",
            "very","just","much","many","well","good","work","new","one","two","three"
    ));

    public static class KeywordResult {
        public double score;
        public Map<String, Integer> keywordFrequency = new LinkedHashMap<>();
        public List<String> topKeywords = new ArrayList<>();
        public List<String> missingKeywords = new ArrayList<>();
    }

    public KeywordResult score(String resumeText, String jobDescriptionText) {
        KeywordResult result = new KeywordResult();

        Map<String, Integer> resumeFreq = computeFrequency(resumeText);

        if (jobDescriptionText != null && !jobDescriptionText.isBlank()) {
            // JD given — compute keyword overlap
            Map<String, Integer> jdFreq = computeFrequency(jobDescriptionText);
            result.score = computeOverlapScore(resumeFreq, jdFreq, result);
        } else {
            // No JD — score based on resume keyword richness
            result.score = computeRichnessScore(resumeFreq, result);
        }

        result.score = Math.min(100, Math.max(0, result.score));
        result.keywordFrequency = resumeFreq.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(20)
                .collect(Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue,
                        (e1, e2) -> e1, LinkedHashMap::new));

        result.topKeywords = new ArrayList<>(result.keywordFrequency.keySet())
                .stream().limit(10).collect(Collectors.toList());

        log.info("KeywordScore: {}/100 — topKeywords:{}", result.score, result.topKeywords);
        return result;
    }

    /**
     * TF-IDF inspired overlap score between resume and JD keywords.
     * Score = (matching keywords / total JD keywords) * 100
     */
    private double computeOverlapScore(Map<String, Integer> resumeFreq,
                                       Map<String, Integer> jdFreq,
                                       KeywordResult result) {
        if (jdFreq.isEmpty()) return computeRichnessScore(resumeFreq, result);

        Set<String> jdKeywords    = jdFreq.keySet();
        Set<String> resumeKeywords = resumeFreq.keySet();

        long matched = jdKeywords.stream()
                .filter(resumeKeywords::contains)
                .count();

        jdKeywords.stream()
                .filter(k -> !resumeKeywords.contains(k))
                .limit(10)
                .forEach(result.missingKeywords::add);

        return (double) matched / jdKeywords.size() * 100;
    }

    /**
     * Score keyword richness when no JD is given.
     * Based on number of unique meaningful words.
     */
    private double computeRichnessScore(Map<String, Integer> freq, KeywordResult result) {
        int uniqueWords = freq.size();
        if (uniqueWords >= 60) return 100;
        if (uniqueWords >= 45) return 85;
        if (uniqueWords >= 30) return 70;
        if (uniqueWords >= 20) return 55;
        if (uniqueWords >= 10) return 35;
        return 15;
    }

    /**
     * Compute word frequency map from text.
     * Filters stop words and short words.
     */
    private Map<String, Integer> computeFrequency(String text) {
        Map<String, Integer> freq = new LinkedHashMap<>();
        String[] tokens = text.toLowerCase()
                .replaceAll("[^a-zA-Z0-9+#.\\s]", " ")
                .split("\\s+");

        for (String token : tokens) {
            token = token.trim();
            // Keep meaningful tokens: length > 2, not a stop word, not a number
            if (token.length() > 2 && !STOP_WORDS.contains(token) && !token.matches("\\d+")) {
                freq.merge(token, 1, Integer::sum);
            }
        }

        // Remove very common single-char tokens
        freq.entrySet().removeIf(e -> e.getKey().length() < 3);

        return freq;
    }
}
