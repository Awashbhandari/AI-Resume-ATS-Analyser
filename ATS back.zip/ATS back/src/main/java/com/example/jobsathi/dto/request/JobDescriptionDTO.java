package com.example.jobsathi.dto.request;

import lombok.Data;

/**
 * Holds the job description fields sent from the frontend.
 * jobTitle is required. Everything else is optional.
 */
@Data
public class JobDescriptionDTO {
    private String jobTitle;           // required
    private String requiredSkills;     // optional — comma separated
    private String experienceRequired; // optional — e.g. "2+ years"
    private String educationRequired;  // optional — e.g. "Bachelor's degree"
}
