package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Scores education by detecting degree level in resume text.
 * If JD education requirement given — compares against it.
 * If not given — uses default scale.
 *
 * Degree levels (ascending):
 *   1 = High School / SLC / SEE
 *   2 = Diploma / Certificate / +2 / A-Level
 *   3 = Bachelor's / B.Sc / B.Tech / BA / BBA / BCA / BE
 *   4 = Master's / M.Sc / MBA / M.Tech / MA / MCA / ME
 *   5 = PhD / Doctorate / Ph.D
 */
@Service
public class EducationScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EducationScoringService.class);

    public static class EducationResult {
        public double score;
        public String highestDegree;
        public int degreeLevel; // 1-5
        public String institution;
        public boolean hasGpa;
        public boolean hasHonours;
    }

    public EducationResult score(String resumeText, String educationRequired) {
        EducationResult result = new EducationResult();
        String lower = resumeText.toLowerCase();

        // ── Detect degree level ──
        result.degreeLevel = detectDegreeLevel(lower);
        result.highestDegree = degreeLabel(result.degreeLevel);

        // ── Detect GPA / Honours ──
        result.hasGpa     = lower.contains("gpa") || lower.contains("cgpa") ||
                            lower.contains("grade point");
        result.hasHonours = lower.contains("honour") || lower.contains("honor") ||
                            lower.contains("distinction") || lower.contains("cum laude") ||
                            lower.contains("first division") || lower.contains("merit");

        // ── Detect institution ──
        result.institution = detectInstitution(resumeText);

        // ── Score ──
        if (educationRequired != null && !educationRequired.isBlank()) {
            result.score = scoreAgainstJD(result.degreeLevel, educationRequired);
        } else {
            result.score = defaultScale(result.degreeLevel);
        }

        // Bonus for GPA or honours
        if (result.hasGpa || result.hasHonours) {
            result.score = Math.min(100, result.score + 5);
        }

        log.info("EducationScore: {}/100 — degree:{} level:{}",
                result.score, result.highestDegree, result.degreeLevel);

        return result;
    }

    private int detectDegreeLevel(String lower) {
        // PhD — highest
        if (lower.contains("phd") || lower.contains("ph.d") ||
            lower.contains("doctorate") || lower.contains("doctoral")) return 5;

        // Master's
        if (lower.contains("master") || lower.contains("m.sc") || lower.contains("msc") ||
            lower.contains("mba") || lower.contains("m.tech") || lower.contains("mtech") ||
            lower.contains("m.a.") || lower.contains(" ma ") || lower.contains("mca") ||
            lower.contains("m.e.") || lower.contains("m.phil")) return 4;

        // Bachelor's
        if (lower.contains("bachelor") || lower.contains("b.sc") || lower.contains("bsc") ||
            lower.contains("b.tech") || lower.contains("btech") || lower.contains("b.e.") ||
            lower.contains("bca") || lower.contains("bba") || lower.contains("b.a.") ||
            lower.contains("be ") || lower.contains("b.com") || lower.contains("csit") ||
            lower.contains("undergraduate") || lower.contains("honours degree")) return 3;

        // Diploma / +2
        if (lower.contains("diploma") || lower.contains("certificate") ||
            lower.contains("+2") || lower.contains("a-level") || lower.contains("a level") ||
            lower.contains("higher secondary") || lower.contains("intermediate") ||
            lower.contains("associate degree") || lower.contains("10+2")) return 2;

        // High School
        if (lower.contains("high school") || lower.contains("slc") || lower.contains("see") ||
            lower.contains("secondary school") || lower.contains("grade 10") ||
            lower.contains("ssc") || lower.contains("matric")) return 1;

        return 0; // Not found
    }

    private String degreeLabel(int level) {
        return switch (level) {
            case 5 -> "PhD / Doctorate";
            case 4 -> "Master's Degree";
            case 3 -> "Bachelor's Degree";
            case 2 -> "Diploma / +2";
            case 1 -> "High School";
            default -> "Not Specified";
        };
    }

    private String detectInstitution(String text) {
        String[] lines = text.split("\n");
        for (String line : lines) {
            String l = line.toLowerCase();
            if (l.contains("university") || l.contains("college") ||
                l.contains("institute") || l.contains("school of")) {
                return line.trim();
            }
        }
        return null;
    }

    /**
     * Compare resume degree level against JD requirement.
     */
    private double scoreAgainstJD(int resumeLevel, String requirement) {
        String lower = requirement.toLowerCase();
        int requiredLevel = 0;

        if (lower.contains("phd") || lower.contains("doctorate")) requiredLevel = 5;
        else if (lower.contains("master") || lower.contains("mba") || lower.contains("postgraduate")) requiredLevel = 4;
        else if (lower.contains("bachelor") || lower.contains("degree") ||
                 lower.contains("graduate") || lower.contains("b.sc") || lower.contains("bsc")) requiredLevel = 3;
        else if (lower.contains("diploma") || lower.contains("+2") || lower.contains("intermediate")) requiredLevel = 2;
        else if (lower.contains("high school") || lower.contains("slc") || lower.contains("see")) requiredLevel = 1;
        else return defaultScale(resumeLevel); // Cannot parse JD — use default

        if (resumeLevel >= requiredLevel) return 100;      // Meets or exceeds

        int gap = requiredLevel - resumeLevel;
        if (gap == 1) return 55;   // One level below
        if (gap == 2) return 25;   // Two levels below
        return 10;                 // Very far below
    }

    /**
     * Default scoring when no JD education requirement given.
     */
    private double defaultScale(int level) {
        return switch (level) {
            case 5 -> 100;
            case 4 -> 85;
            case 3 -> 70;
            case 2 -> 40;
            case 1 -> 20;
            default -> 10;
        };
    }
}
