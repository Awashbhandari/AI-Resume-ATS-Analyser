package com.example.jobsathi.service.scoring;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Scores skill match between resume and job description.
 *
 * Flow:
 * 1. Extract skills from resume using skills_dictionary.csv
 * 2. If JD skills provided → use those as required skills
 *    If JD skills empty but job title given → look up job title in CSV for expected skills
 * 3. TF-IDF cosine similarity between resume skills and required skills → score
 */
@Service

public class SkillScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SkillScoringService.class);

    // Map: job_title (lowercase) → list of expected skills
    private final Map<String, List<String>> jobSkillsMap = new LinkedHashMap<>();

    // Full skills vocabulary loaded from CSV
    private final Set<String> allKnownSkills = new LinkedHashSet<>();

    @PostConstruct
    public void loadDictionary() {
        try {
            ClassPathResource resource = new ClassPathResource("skills_dictionary.csv");
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(resource.getInputStream()))) {
                String line;
                boolean firstLine = true;
                while ((line = br.readLine()) != null) {
                    if (firstLine) { firstLine = false; continue; } // skip header
                    line = line.trim();
                    if (line.isEmpty()) continue;

                    // Parse: "job_title","skill1,skill2,skill3"
                    String[] parts = line.split(",", 2);
                    if (parts.length < 2) continue;

                    String jobTitle  = parts[0].replaceAll("\"", "").trim().toLowerCase();
                    String skillsPart = parts[1].replaceAll("\"", "").trim();
                    List<String> skills = Arrays.stream(skillsPart.split(","))
                            .map(String::trim)
                            .map(String::toLowerCase)
                            .filter(s -> !s.isEmpty())
                            .collect(Collectors.toList());

                    jobSkillsMap.put(jobTitle, skills);
                    allKnownSkills.addAll(skills);
                }
                log.info("Loaded {} job titles and {} skills from dictionary",
                        jobSkillsMap.size(), allKnownSkills.size());
            }
        } catch (Exception e) {
            log.warn("skills_dictionary.csv not found or failed to load: {}", e.getMessage());
        }
    }

    public static class SkillResult {
        public double score;
        public List<String> resumeSkills   = new ArrayList<>();
        public List<String> requiredSkills = new ArrayList<>();
        public List<String> matchedSkills  = new ArrayList<>();
        public List<String> missingSkills  = new ArrayList<>();
        public String skillSource; // "JD_PROVIDED", "JD_INFERRED", "RESUME_ONLY"
    }

    public SkillResult score(String resumeText, String jdSkills, String jobTitle) {
        SkillResult result = new SkillResult();

        // Step 1 — Extract skills from resume
        result.resumeSkills = extractSkillsFromText(resumeText);

        // Step 2 — Get required skills
        if (jdSkills != null && !jdSkills.isBlank()) {
            // JD skills explicitly provided
            result.requiredSkills = Arrays.stream(jdSkills.split(","))
                    .map(String::trim).map(String::toLowerCase)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
            result.skillSource = "JD_PROVIDED";
            log.info("Using JD-provided skills: {}", result.requiredSkills);

        } else if (jobTitle != null && !jobTitle.isBlank()) {
            // Infer skills from job title using CSV dictionary
            result.requiredSkills = inferSkillsFromJobTitle(jobTitle);
            result.skillSource = "JD_INFERRED";
            log.info("Inferred skills from job title '{}': {}", jobTitle, result.requiredSkills);

        } else {
            // No JD info — score based on resume skill count only
            result.skillSource = "RESUME_ONLY";
            result.score = scoreByCount(result.resumeSkills.size());
            return result;
        }

        // Step 3 — TF-IDF Cosine Similarity
        if (result.requiredSkills.isEmpty()) {
            result.score = scoreByCount(result.resumeSkills.size());
            return result;
        }

        result.score = cosineSimilarity(result.resumeSkills, result.requiredSkills);

        // Step 4 — Find matched and missing
        Set<String> resumeSet   = new HashSet<>(result.resumeSkills);
        Set<String> requiredSet = new HashSet<>(result.requiredSkills);

        for (String skill : requiredSet) {
            if (resumeSet.contains(skill)) {
                // Exact match
                result.matchedSkills.add(skill);
            } else {
                // Strict partial match — only if resume skill
                // is at least 4 chars and is a complete word in required skill
                boolean strictMatch = result.resumeSkills.stream()
                        .filter(rs -> rs.length() >= 4)
                        .anyMatch(rs -> {
                            // resume skill must fully contain required skill word
                            // NOT the other way around
                            return rs.equals(skill) ||
                                    (skill.contains(" ") && rs.contains(skill));
                        });

                if (strictMatch) {
                    result.matchedSkills.add(skill);
                } else {
                    result.missingSkills.add(skill);
                }
            }
        }

        // Recalculate score based on actual matches for better accuracy
        double matchScore = (double) result.matchedSkills.size() / requiredSet.size() * 100;
        // Average cosine + match score for robustness
        result.score = (result.score + matchScore) / 2;
        result.score = Math.min(100, Math.max(0, result.score));
        result.score = Math.round(result.score * 10.0) / 10.0;

        log.info("SkillScore: {}/100 — matched:{}/{} source:{}",
                result.score, result.matchedSkills.size(),
                result.requiredSkills.size(), result.skillSource);

        return result;
    }

    /**
     * Extract skills from resume text by matching against known skills dictionary.
     */
    private List<String> extractSkillsFromText(String resumeText) {
        String lower = resumeText.toLowerCase();
        List<String> found = new ArrayList<>();

        for (String skill : allKnownSkills) {
            String skillLower = skill.toLowerCase().trim();
            if (containsWholePhrase(lower, skillLower)) {
                if (!found.contains(skillLower)) {
                    found.add(skillLower);
                }
            }
        }

        int skillsIdx = lower.indexOf("skills");
        if (skillsIdx != -1) {
            String skillsSection = lower.substring(skillsIdx,
                    Math.min(skillsIdx + 800, lower.length()));
            Arrays.stream(skillsSection.split("[,\n•\\-–|/\\t]"))
                    .map(String::trim)
                    .map(String::toLowerCase)
                    .filter(s -> s.length() > 1 && s.length() < 40)
                    .filter(s -> !s.isBlank())
                    .filter(s -> allKnownSkills.contains(s)) // ← ADD THIS LINE
                    .forEach(s -> {
                        if (!found.contains(s)) found.add(s);
                    });
        }

        return found;
    }

    private boolean containsWholePhrase(String text, String phrase) {
        if (!phrase.contains(" ")) {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                    "(?<![a-zA-Z0-9])" +
                            java.util.regex.Pattern.quote(phrase) +
                            "(?![a-zA-Z0-9])"
            );
            return p.matcher(text).find();
        } else {
            return text.contains(phrase);
        }
    }

    /**
     * Find expected skills for a job title using the CSV dictionary.
     * Uses fuzzy matching if exact title not found.
     */
    private List<String> inferSkillsFromJobTitle(String jobTitle) {
        String lower = jobTitle.toLowerCase().trim();

        // Exact match
        if (jobSkillsMap.containsKey(lower)) {
            return jobSkillsMap.get(lower);
        }

        // Partial match — find the closest title
        List<String> bestMatch = new ArrayList<>();
        int bestScore = 0;

        for (Map.Entry<String, List<String>> entry : jobSkillsMap.entrySet()) {
            int matchScore = similarityScore(lower, entry.getKey());
            if (matchScore > bestScore) {
                bestScore = matchScore;
                bestMatch = entry.getValue();
            }
        }

        if (bestScore > 0) return bestMatch;

        // Last resort — extract keywords from job title itself
        return Arrays.stream(lower.split("\\s+"))
                .filter(w -> w.length() > 3)
                .collect(Collectors.toList());
    }

    /**
     * TF-IDF Cosine Similarity between two skill lists.
     * Treats each skill list as a document.
     * Score = dot product / (magnitude1 * magnitude2)
     */
    private double cosineSimilarity(List<String> resumeSkills, List<String> requiredSkills) {
        // Build vocabulary
        Set<String> vocab = new HashSet<>();
        vocab.addAll(resumeSkills);
        vocab.addAll(requiredSkills);

        // Build TF vectors
        Map<String, Double> resumeVector   = buildTFVector(resumeSkills, vocab);
        Map<String, Double> requiredVector = buildTFVector(requiredSkills, vocab);

        // Cosine similarity
        double dotProduct  = 0;
        double resumeMag   = 0;
        double requiredMag = 0;

        for (String term : vocab) {
            double rv = resumeVector.getOrDefault(term, 0.0);
            double qv = requiredVector.getOrDefault(term, 0.0);
            dotProduct  += rv * qv;
            resumeMag   += rv * rv;
            requiredMag += qv * qv;
        }

        if (resumeMag == 0 || requiredMag == 0) return 0;
        double similarity = dotProduct / (Math.sqrt(resumeMag) * Math.sqrt(requiredMag));
        return Math.round(similarity * 1000) / 10.0; // Convert to 0-100 scale
    }

    private Map<String, Double> buildTFVector(List<String> skills, Set<String> vocab) {
        Map<String, Double> vector = new HashMap<>();
        for (String term : vocab) {
            long count = skills.stream().filter(s -> s.equalsIgnoreCase(term)).count();
            vector.put(term, count > 0 ? 1.0 + Math.log(count) : 0.0);
        }
        return vector;
    }

    /** Score when no JD is available — based on skill count */
    private double scoreByCount(int count) {
        if (count >= 15) return 100;
        if (count >= 10) return 80;
        if (count >= 7)  return 65;
        if (count >= 4)  return 45;
        if (count >= 1)  return 25;
        return 5;
    }

    /** Simple word overlap score for fuzzy job title matching */
    private int similarityScore(String a, String b) {
        Set<String> wordsA = new HashSet<>(Arrays.asList(a.split("\\s+")));
        Set<String> wordsB = new HashSet<>(Arrays.asList(b.split("\\s+")));
        Set<String> common = new HashSet<>(wordsA);
        common.retainAll(wordsB);
        return common.size();
    }
}

// Java's Pattern class import helper
class Pattern {
    static String quote(String s) {
        return java.util.regex.Pattern.quote(s);
    }
}
