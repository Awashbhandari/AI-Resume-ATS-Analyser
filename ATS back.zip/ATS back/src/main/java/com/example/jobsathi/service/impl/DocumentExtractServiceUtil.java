package com.example.jobsathi.service.impl;

import com.example.jobsathi.exception.ResumeException;
import com.example.jobsathi.util.DocType;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

/**
 * Extracts plain text from uploaded resume files.
 * Supports PDF and DOCX formats.
 *
 * DOCX support added using Apache POI (add to pom.xml if not present).
 */
public class DocumentExtractServiceUtil {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DocumentExtractServiceUtil.class);

    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024L; // 10 MB

    public static String extractText(MultipartFile file, String extension) {
        log.info("Extracting text from file: {} ({})", file.getOriginalFilename(), extension);
        validateFile(file);

        String fileName = file.getOriginalFilename();
        if (fileName == null || fileName.isBlank()) {
            throw new ResumeException("Filename is missing");
        }

        return switch (DocType.fromExtension(extension)) {
            case PDF  -> extractPDF(file);
            case DOCX -> extractDocx(file);
        };
    }

    // ── PDF Extraction using Apache PDFBox ──────────────────────────────────
    private static String extractPDF(MultipartFile file) {
        log.info("Extracting PDF text");
        try {
            PDDocument pdf = Loader.loadPDF(file.getBytes());
            if (pdf.isEncrypted()) {
                throw new ResumeException("PDF is password-protected. Please upload an unencrypted PDF.");
            }
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            stripper.setAddMoreFormatting(true);
            String text = stripper.getText(pdf);
            pdf.close();
            String result = normalise(text);
            log.info("PDF extraction complete — {} characters extracted", result.length());
            return result;
        } catch (ResumeException e) {
            throw e;
        } catch (Exception e) {
            throw new ResumeException("Failed to read PDF: " + e.getMessage());
        }
    }

    // ── DOCX Extraction using Apache POI ────────────────────────────────────
    private static String extractDocx(MultipartFile file) {
        log.info("Extracting DOCX text");
        try {
            // Use reflection to avoid compile error if POI not in classpath
            // Add this to pom.xml:
            // <dependency>
            //   <groupId>org.apache.poi</groupId>
            //   <artifactId>poi-ooxml</artifactId>
            //   <version>5.2.3</version>
            // </dependency>

            InputStream is = file.getInputStream();

            // Try Apache POI XWPFWordExtractor
            Class<?> xwpfDoc  = Class.forName("org.apache.poi.xwpf.usermodel.XWPFDocument");
            Class<?> extractor = Class.forName("org.apache.poi.xwpf.extractor.XWPFWordExtractor");

            Object document  = xwpfDoc.getConstructor(InputStream.class).newInstance(is);
            Object ext       = extractor.getConstructor(xwpfDoc).newInstance(document);
            String text      = (String) extractor.getMethod("getText").invoke(ext);

            is.close();
            String result = normalise(text);
            log.info("DOCX extraction complete — {} characters extracted", result.length());
            return result;

        } catch (ClassNotFoundException e) {
            // POI not in classpath — return helpful message
            throw new ResumeException(
                "DOCX extraction requires Apache POI. " +
                "Please add poi-ooxml dependency to pom.xml or upload a PDF instead.");
        } catch (Exception e) {
            throw new ResumeException("Failed to read DOCX: " + e.getMessage());
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────────
    public static String getExtension(String originalFilename) {
        int dot = originalFilename.lastIndexOf(".");
        return dot == -1 ? "" : originalFilename.substring(dot + 1).toLowerCase();
    }

    public static void validateFile(MultipartFile file) {
        if (file.isEmpty()) {
            throw new ResumeException("File is empty or missing.");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new ResumeException("File exceeds 10MB limit.");
        }
    }

    private static String normalise(String raw) {
        if (raw == null) return "";
        return raw
                .replace("\r\n", "\n")
                .replaceAll("\n{3,}", "\n\n")
                .replaceAll("[ \t]+", " ")
                .trim();
    }
}
