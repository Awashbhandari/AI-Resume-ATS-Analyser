package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Scores verb diversity by checking action verbs across 7 categories.
 * Each category found = ~14 points. Maximum = 100.
 * No AI needed — pure word matching.
 *
 * 7 Categories:
 *   1. Leadership
 *   2. Building / Development
 *   3. Analysis
 *   4. Delivery / Execution
 *   5. Communication / Collaboration
 *   6. Optimisation / Improvement
 *   7. Achievement / Results
 */
@Service
public class VerbDiversityScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(VerbDiversityScoringService.class);

    private static final Map<String, List<String>> VERB_CATEGORIES = new LinkedHashMap<>();

    static {
        VERB_CATEGORIES.put("Leadership", Arrays.asList(
                "led", "managed", "directed", "supervised", "coordinated", "oversaw",
                "mentored", "guided", "organized", "spearheaded", "headed", "chaired",
                "administered", "commanded", "governed", "steered", "championed"
        ));
        VERB_CATEGORIES.put("Building", Arrays.asList(
                "built", "developed", "created", "designed", "implemented", "architected",
                "engineered", "constructed", "established", "launched", "founded",
                "programmed", "coded", "wrote", "crafted", "assembled", "configured",
                "deployed", "installed", "integrated", "modelled"
        ));
        VERB_CATEGORIES.put("Analysis", Arrays.asList(
                "analyzed", "researched", "evaluated", "assessed", "investigated",
                "examined", "reviewed", "diagnosed", "identified", "measured",
                "audited", "calculated", "forecasted", "interpreted", "monitored",
                "tracked", "surveyed", "tested", "validated", "verified"
        ));
        VERB_CATEGORIES.put("Delivery", Arrays.asList(
                "delivered", "completed", "achieved", "accomplished", "executed",
                "shipped", "released", "produced", "finished", "met", "fulfilled",
                "submitted", "finalized", "processed", "handled", "performed"
        ));
        VERB_CATEGORIES.put("Communication", Arrays.asList(
                "presented", "communicated", "collaborated", "negotiated", "reported",
                "documented", "trained", "facilitated", "articulated", "conveyed",
                "advised", "consulted", "liaised", "pitched", "proposed", "briefed",
                "educated", "informed", "drafted", "authored", "published"
        ));
        VERB_CATEGORIES.put("Optimisation", Arrays.asList(
                "improved", "optimized", "streamlined", "enhanced", "reduced",
                "increased", "accelerated", "automated", "simplified", "refined",
                "upgraded", "restructured", "consolidated", "minimized", "maximized",
                "boosted", "strengthened", "transformed", "revamped", "modernized"
        ));
        VERB_CATEGORIES.put("Achievement", Arrays.asList(
                "won", "earned", "received", "awarded", "exceeded", "surpassed",
                "generated", "saved", "grew", "doubled", "tripled", "ranked",
                "secured", "attained", "demonstrated", "pioneered", "innovated",
                "outperformed", "recognized", "promoted"
        ));
    }

    private static final List<String> WEAK_PHRASES = Arrays.asList(
            "responsible for", "worked on", "helped with", "assisted in",
            "was involved in", "participated in", "tried to", "attempted to",
            "duties included", "in charge of", "tasked with"
    );

    public static class VerbResult {
        public double score;
        public List<String> actionVerbsFound = new ArrayList<>();
        public Map<String, Integer> verbFrequency = new LinkedHashMap<>();
        public List<String> overusedVerbs = new ArrayList<>();
        public List<String> verbSuggestions = new ArrayList<>();
        public List<String> weakPhrasesFound = new ArrayList<>();
        public List<String> categoriesFound = new ArrayList<>();
        public int criticalWeakCount;
        public int minorWeakCount;
    }

    public VerbResult score(String resumeText) {
        VerbResult result = new VerbResult();
        String lower = resumeText.toLowerCase();
        String[] words = lower.split("[\\s,;.!?()\\[\\]{}\"']+");
        Set<String> wordSet = new HashSet<>(Arrays.asList(words));

        // ── Check each category ──
        int categoriesFound = 0;
        for (Map.Entry<String, List<String>> entry : VERB_CATEGORIES.entrySet()) {
            boolean categoryFound = false;
            for (String verb : entry.getValue()) {
                if (wordSet.contains(verb)) {
                    result.actionVerbsFound.add(verb);
                    categoryFound = true;
                    // Count frequency
                    int freq = 0;
                    for (String w : words) {
                        if (w.equals(verb)) freq++;
                    }
                    result.verbFrequency.put(verb, freq);
                    if (freq >= 4) result.overusedVerbs.add(verb);
                }
            }
            if (categoryFound) {
                categoriesFound++;
                result.categoriesFound.add(entry.getKey());
            } else {
                // Suggest missing categories
                String suggestion = entry.getValue().get(0);
                result.verbSuggestions.add("Add " + entry.getKey().toLowerCase() +
                        " verbs — e.g. '" + suggestion + "'");
            }
        }

        // ── Check weak phrases ──
        for (String phrase : WEAK_PHRASES) {
            if (lower.contains(phrase)) {
                result.weakPhrasesFound.add(phrase);
                result.criticalWeakCount++;
            }
        }

        // ── Score: each category = ~14.28 pts, cap at 100 ──
        result.score = Math.min(100, categoriesFound * (100.0 / 7));
        result.score = Math.round(result.score * 10.0) / 10.0;

        // Penalty for weak phrases
        double penalty = result.criticalWeakCount * 5.0;
        result.score = Math.max(0, result.score - penalty);

        log.info("VerbDiversityScore: {}/100 — categories:{}/7 weakPhrases:{}",
                result.score, categoriesFound, result.criticalWeakCount);

        return result;
    }
}
