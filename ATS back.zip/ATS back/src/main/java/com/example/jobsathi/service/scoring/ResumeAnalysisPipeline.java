package com.example.jobsathi.service.scoring;

import com.example.jobsathi.dto.request.JobDescriptionDTO;
import com.example.jobsathi.dto.response.ResumeScoreResponseDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Main scoring pipeline.
 * Orchestrates all 8 scoring services and returns the final ResumeScoreResponseDTO.
 *
 * This replaces the AI-only scoring approach with a hybrid:
 *   - Skills    → TF-IDF Cosine Similarity + CSV Dictionary
 *   - Grammar   → LanguageTool
 *   - Format    → Rule-based Java
 *   - Contact   → Regex
 *   - Experience→ Date Regex + JD comparison
 *   - Education → Keyword matching + JD comparison
 *   - Verbs     → Action verb word list (7 categories)
 *   - Keywords  → TF-IDF frequency analysis
 */
@Service
@RequiredArgsConstructor
public class ResumeAnalysisPipeline {
        private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ResumeAnalysisPipeline.class);

    private final SkillScoringService    skillService;
    private final GrammarScoringService  grammarService;
    private final FormatScoringService   formatService;
    private final ContactScoringService  contactService;
    private final ExperienceScoringService experienceService;
    private final EducationScoringService  educationService;
    private final VerbDiversityScoringService verbService;
    private final KeywordScoringService   keywordService;

    // TF-IDF Weights
    private static final double SKILL_WEIGHT      = 0.28;
    private static final double GRAMMAR_WEIGHT    = 0.18;
    private static final double FORMAT_WEIGHT     = 0.18;
    private static final double KEYWORD_WEIGHT    = 0.18;
    private static final double EXPERIENCE_WEIGHT = 0.14;
    private static final double EDUCATION_WEIGHT  = 0.14;
    private static final double CONTACT_WEIGHT    = 0.14;
    private static final double VERB_WEIGHT       = 0.14;

    public ResumeScoreResponseDTO analyse(String resumeText,
                                          String fileType,
                                          JobDescriptionDTO jd) {
        log.info("Starting ResumeAnalysisPipeline for jobTitle: {}", jd.getJobTitle());

        // Full JD text for keyword overlap
        String jdFullText = buildJDText(jd);

        // ── Run all 8 scoring services ──
        var skillResult      = skillService.score(resumeText, jd.getRequiredSkills(), jd.getJobTitle());
        var grammarResult    = grammarService.score(resumeText);
        var formatResult     = formatService.score(resumeText);
        var contactResult    = contactService.score(resumeText);
        var experienceResult = experienceService.score(resumeText, jd.getExperienceRequired());
        var educationResult  = educationService.score(resumeText, jd.getEducationRequired());
        var verbResult       = verbService.score(resumeText);
        var keywordResult    = keywordService.score(resumeText, jdFullText);

        // ── TF-IDF Weighted Composite Score ──
        double overall = round1(
                (skillResult.score      * SKILL_WEIGHT)  +
                (grammarResult.score    * GRAMMAR_WEIGHT) +
                (formatResult.score     * FORMAT_WEIGHT)  +
                (keywordResult.score    * KEYWORD_WEIGHT) +
                (experienceResult.score * EXPERIENCE_WEIGHT) +
                (educationResult.score  * EDUCATION_WEIGHT) +
                (contactResult.score    * CONTACT_WEIGHT) +
                (verbResult.score       * VERB_WEIGHT)
        );
        overall = Math.min(100, Math.max(0, overall));

        String grade   = grade(overall);
        String verdict = verdict(overall);

        log.info("Pipeline complete — Overall:{}/100 Grade:{}", overall, grade);

        return ResumeScoreResponseDTO.builder()
                // ── Overall ──
                .overallScore(overall)
                .grade(grade)
                .verdict(verdict)
                .feedback(buildFeedback(overall, skillResult, grammarResult, verbResult))
                .scoringFormula(buildFormula(skillResult.score, grammarResult.score,
                        formatResult.score, keywordResult.score,
                        experienceResult.score, educationResult.score,
                        contactResult.score, verbResult.score))

                // ── 8 Dimension Scores ──
                .skillScore(round1(skillResult.score))
                .grammarScore(round1(grammarResult.score))
                .formatScore(round1(formatResult.score))
                .keywordScore(round1(keywordResult.score))
                .experienceScore(round1(experienceResult.score))
                .educationScore(round1(educationResult.score))
                .contactScore(round1(contactResult.score))
                .verbDiversityScore(round1(verbResult.score))

                // ── Skills ──
                .matchedSkills(skillResult.matchedSkills)
                .missingSkills(skillResult.missingSkills)

                // ── Grammar ──
                .grammarIssueCount(grammarResult.issueCount)
                .grammarIssues(grammarResult.issues)

                // ── Contact ──
                .hasContact(contactResult.hasContact)
                .email(contactResult.email)
                .phone(contactResult.phone)
                .linkedIn(contactResult.linkedIn)
                .gitHub(contactResult.gitHub)

                // ── Format ──
                .hasExperience(formatResult.hasExperience)
                .hasEducation(formatResult.hasEducation)
                .hasSkills(formatResult.hasSkills)
                .hasSummary(formatResult.hasSummary)
                .hasProjects(formatResult.hasProjects)
                .hasCertifications(formatResult.hasCertifications)
                .detectedSections(formatResult.detectedSections)

                // ── Experience ──
                .yearsExperience(experienceResult.yearsExperience)
                .dateRanges(experienceResult.dateRanges)
                .hasCurrentRole(experienceResult.hasCurrentRole)
                .jobCount(experienceResult.jobCount)

                // ── Education ──
                .highestDegree(educationResult.highestDegree)
                .institution(educationResult.institution)
                .hasGpa(educationResult.hasGpa)
                .hasHonours(educationResult.hasHonours)

                // ── Verbs ──
                .actionVerbsFound(verbResult.actionVerbsFound)
                .verbFrequency(verbResult.verbFrequency)
                .overusedVerbs(verbResult.overusedVerbs)
                .verbSuggestions(verbResult.verbSuggestions)

                // ── Keywords ──
                .topKeywords(keywordResult.topKeywords)
                .keywordFrequency(keywordResult.keywordFrequency)
                .missingKeywords(keywordResult.missingKeywords)

                // ── Document stats ──
                .wordCount(formatResult.wordCount)
                .sentenceCount(Math.max(1, resumeText.split("[.!?]+").length))
                .bulletCount(formatResult.bulletCount)
                .fileType(fileType)
                .extractedTextPreview(resumeText.length() > 300
                        ? resumeText.substring(0, 300).replaceAll("\\s+", " ") + "..."
                        : resumeText)

                // ── AI provider label ──
                .aiProvider("Rule-Based NLP + TF-IDF Cosine Similarity")
                .inferredRole(jd.getJobTitle())

                .build();
    }

    private String buildJDText(JobDescriptionDTO jd) {
        StringBuilder sb = new StringBuilder();
        if (jd.getJobTitle()         != null) sb.append(jd.getJobTitle()).append(" ");
        if (jd.getRequiredSkills()   != null) sb.append(jd.getRequiredSkills()).append(" ");
        if (jd.getExperienceRequired()!= null) sb.append(jd.getExperienceRequired()).append(" ");
        if (jd.getEducationRequired() != null) sb.append(jd.getEducationRequired()).append(" ");
        return sb.toString();
    }

    private String buildFormula(double skill, double grammar, double format,
                                 double keyword, double exp, double edu,
                                 double contact, double verb) {
        return String.format(
                "Skills(%.0f)×28%% + Grammar(%.0f)×18%% + Format(%.0f)×18%% + " +
                "Keywords(%.0f)×18%% + Experience(%.0f)×14%% + Education(%.0f)×14%% + " +
                "Contact(%.0f)×14%% + VerbDiv(%.0f)×14%%",
                skill, grammar, format, keyword, exp, edu, contact, verb);
    }

    private String buildFeedback(double score,
                                  SkillScoringService.SkillResult skill,
                                  GrammarScoringService.GrammarResult grammar,
                                  VerbDiversityScoringService.VerbResult verb) {
        StringBuilder sb = new StringBuilder();
        if (score >= 85)      sb.append("Strong resume. ");
        else if (score >= 70) sb.append("Good resume with room to improve. ");
        else if (score >= 55) sb.append("Average resume — needs revision. ");
        else                  sb.append("Resume needs significant revision. ");

        sb.append(skill.matchedSkills.size()).append(" skills matched. ");
        if (grammar.issueCount > 0)
            sb.append(grammar.issueCount).append(" grammar issue(s). ");
        if (verb.criticalWeakCount > 0)
            sb.append(verb.criticalWeakCount).append(" weak phrase(s) to replace. ");
        if (!skill.missingSkills.isEmpty())
            sb.append("Add missing skills: ")
              .append(String.join(", ", skill.missingSkills.subList(
                      0, Math.min(3, skill.missingSkills.size())))).append(". ");

        return sb.toString().trim();
    }

    private String grade(double s) {
        if (s >= 85) return "A";
        if (s >= 70) return "B";
        if (s >= 55) return "C";
        if (s >= 40) return "D";
        return "F";
    }

    private String verdict(double s) {
        if (s >= 85) return "Strong Resume — Likely to pass ATS screening";
        if (s >= 70) return "Good Resume — Minor improvements recommended";
        if (s >= 55) return "Average Resume — Moderate revision required";
        if (s >= 40) return "Weak Resume — Significant revision required";
        return "Poor Resume — Major overhaul recommended";
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
