package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Scores the resume format using rule-based checks.
 * No AI needed — pure string analysis.
 *
 * Scoring breakdown:
 *   Sections present (Experience, Education, Skills, Contact) → 40 pts
 *   Word count 300-800 words                                  → 30 pts
 *   Bullet points used                                        → 20 pts
 *   Professional summary present                              → 10 pts
 *   Total                                                     → 100 pts
 */
@Service

public class FormatScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(FormatScoringService.class);

    public static class FormatResult {
        public double score;
        public boolean hasExperience;
        public boolean hasEducation;
        public boolean hasSkills;
        public boolean hasSummary;
        public boolean hasProjects;
        public boolean hasCertifications;
        public List<String> detectedSections = new ArrayList<>();
        public int wordCount;
        public int bulletCount;
    }

    public FormatResult score(String resumeText) {
        FormatResult result = new FormatResult();
        String lower = resumeText.toLowerCase();

        // ── Count words ──
        String[] words = resumeText.trim().split("\\s+");
        result.wordCount = words.length;

        // ── Count bullets ──
        result.bulletCount = countBullets(resumeText);

        // ── Detect sections ──
        result.hasExperience = containsAny(lower,
                "experience", "work history", "employment", "professional experience", "work experience");
        result.hasEducation = containsAny(lower,
                "education", "academic", "qualification", "degree", "university", "college");
        result.hasSkills = containsAny(lower,
                "skills", "technical skills", "core competencies", "competencies", "expertise");
        result.hasSummary = containsAny(lower,
                "summary", "objective", "profile", "about me", "professional summary", "career objective");
        result.hasProjects = containsAny(lower,
                "project", "projects", "personal project", "academic project");
        result.hasCertifications = containsAny(lower,
                "certification", "certificate", "certified", "license", "award");

        if (result.hasExperience)     result.detectedSections.add("Experience");
        if (result.hasEducation)      result.detectedSections.add("Education");
        if (result.hasSkills)         result.detectedSections.add("Skills");
        if (result.hasSummary)        result.detectedSections.add("Summary");
        if (result.hasProjects)       result.detectedSections.add("Projects");
        if (result.hasCertifications) result.detectedSections.add("Certifications");

        // ── Calculate score ──
        double total = 0;

        // Sections — 40 pts (10 each for core 4)
        int coreSections = 0;
        if (result.hasExperience) coreSections++;
        if (result.hasEducation)  coreSections++;
        if (result.hasSkills)     coreSections++;
        if (result.hasSummary)    coreSections++;
        total += coreSections * 10.0;

        // Word count — 30 pts
        if (result.wordCount >= 300 && result.wordCount <= 800) {
            total += 30;
        } else if (result.wordCount > 800 && result.wordCount <= 1200) {
            total += 20; // slightly too long
        } else if (result.wordCount >= 150 && result.wordCount < 300) {
            total += 15; // too short
        } else {
            total += 5; // very short or very long
        }

        // Bullet points — 20 pts
        if (result.bulletCount >= 10) {
            total += 20;
        } else if (result.bulletCount >= 5) {
            total += 13;
        } else if (result.bulletCount >= 1) {
            total += 7;
        }

        result.score = Math.min(100, total);

        log.info("FormatScore: {}/100 — words:{} bullets:{} sections:{}",
                result.score, result.wordCount, result.bulletCount, result.detectedSections);

        return result;
    }

    private boolean containsAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw)) return true;
        }
        return false;
    }

    private int countBullets(String text) {
        int count = 0;
        for (String line : text.split("\n")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("•") || trimmed.startsWith("-") ||
                trimmed.startsWith("*") || trimmed.startsWith("·") ||
                trimmed.startsWith("▪") || trimmed.startsWith("◦") ||
                trimmed.matches("^\\d+\\.\\s+.*")) {
                count++;
            }
        }
        return count;
    }
}
