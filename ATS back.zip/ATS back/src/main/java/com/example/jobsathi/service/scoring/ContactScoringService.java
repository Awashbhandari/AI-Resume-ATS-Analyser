package com.example.jobsathi.service.scoring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

/**
 * Scores the resume based on contact information present.
 * Uses regex patterns — no AI needed.
 *
 * Scoring:
 *   Email    → 35 points
 *   Phone    → 25 points
 *   LinkedIn → 25 points
 *   GitHub   → 15 points
 *   Total    → 100 points
 */
@Service

public class ContactScoringService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ContactScoringService.class);

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("(\\+?\\d[\\d\\s\\-().]{7,}\\d)");

    private static final Pattern LINKEDIN_PATTERN =
            Pattern.compile("(?i)(linkedin\\.com/in/[a-zA-Z0-9\\-]+|linkedin\\.com)");

    private static final Pattern GITHUB_PATTERN =
            Pattern.compile("(?i)(github\\.com/[a-zA-Z0-9\\-]+|github\\.com)");

    public static class ContactResult {
        public double score;
        public String email;
        public String phone;
        public String linkedIn;
        public String gitHub;
        public boolean hasContact;
    }

    public ContactResult score(String resumeText) {
        ContactResult result = new ContactResult();
        double total = 0;

        // Email — 35 points
        var emailMatcher = EMAIL_PATTERN.matcher(resumeText);
        if (emailMatcher.find()) {
            result.email = emailMatcher.group();
            total += 35;
        }

        // Phone — 25 points
        var phoneMatcher = PHONE_PATTERN.matcher(resumeText);
        if (phoneMatcher.find()) {
            result.phone = phoneMatcher.group().trim();
            total += 25;
        }

        // LinkedIn — 25 points
        var linkedInMatcher = LINKEDIN_PATTERN.matcher(resumeText);
        if (linkedInMatcher.find()) {
            result.linkedIn = linkedInMatcher.group();
            total += 25;
        }

        // GitHub — 15 points
        var githubMatcher = GITHUB_PATTERN.matcher(resumeText);
        if (githubMatcher.find()) {
            result.gitHub = githubMatcher.group();
            total += 15;
        }

        result.score = Math.min(100, total);
        result.hasContact = total > 0;

        log.info("ContactScore: {}/100 — email:{} phone:{} linkedin:{} github:{}",
                result.score,
                result.email != null,
                result.phone != null,
                result.linkedIn != null,
                result.gitHub != null);

        return result;
    }
}
