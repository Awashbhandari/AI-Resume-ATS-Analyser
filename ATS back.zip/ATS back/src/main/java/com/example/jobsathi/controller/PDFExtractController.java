package com.example.jobsathi.controller;

import com.example.jobsathi.dto.request.JobDescriptionDTO;
import com.example.jobsathi.dto.response.ChatResponseDTO;
import com.example.jobsathi.dto.response.ResumeScoreResponseDTO;
import com.example.jobsathi.service.AIService;
import com.example.jobsathi.service.impl.DocumentExtractServiceUtil;
import com.example.jobsathi.service.scoring.ResumeAnalysisPipeline;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * REST Controller for resume analysis.
 * Now accepts job description fields alongside the resume file.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/job-sathi")

public class PDFExtractController {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(PDFExtractController.class);

    private final ResumeAnalysisPipeline pipeline;
    private final AIService aiService; // kept for chat only

    /**
     * Main analysis endpoint.
     * POST /api/job-sathi/analysis
     *
     * Required:  file, jobTitle
     * Optional:  requiredSkills, experienceRequired, educationRequired
     */
    @PostMapping(
            value = "/analysis",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ResumeScoreResponseDTO> analyseResume(
            @RequestParam("file")                               MultipartFile file,
            @RequestParam(value = "jobTitle",           required = false, defaultValue = "") String jobTitle,
            @RequestParam(value = "requiredSkills",     required = false, defaultValue = "") String requiredSkills,
            @RequestParam(value = "experienceRequired", required = false, defaultValue = "") String experienceRequired,
            @RequestParam(value = "educationRequired",  required = false, defaultValue = "") String educationRequired
    ) {
        log.info("Received analysis request — file:{} jobTitle:{}",
                file.getOriginalFilename(), jobTitle);

        // Step 1 — Extract text from file
        String extension  = DocumentExtractServiceUtil.getExtension(
                file.getOriginalFilename() != null ? file.getOriginalFilename() : "resume.pdf");
        String resumeText = DocumentExtractServiceUtil.extractText(file, extension);

        log.info("Extracted {} characters from resume", resumeText.length());

        // Step 2 — Build JD object
        JobDescriptionDTO jd = new JobDescriptionDTO();
        jd.setJobTitle(jobTitle);
        jd.setRequiredSkills(requiredSkills);
        jd.setExperienceRequired(experienceRequired);
        jd.setEducationRequired(educationRequired);

        // Step 3 — Run scoring pipeline
        ResumeScoreResponseDTO result = pipeline.analyse(resumeText, extension, jd);

        return ResponseEntity.ok(result);
    }

    /**
     * Chat endpoint — still uses AI for general career Q&A.
     * POST /api/job-sathi/chat
     */
    @PostMapping("/chat")
    public ResponseEntity<ChatResponseDTO> chat(@RequestParam String chat) {
        return ResponseEntity.ok(aiService.simpleChat(chat));
    }
}
